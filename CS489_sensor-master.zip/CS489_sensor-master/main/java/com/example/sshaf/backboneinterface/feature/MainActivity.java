//Corresponds with activity_main.xml
package com.example.sshaf.backboneinterface.feature;

import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.*;
import android.view.View.OnClickListener;

public class MainActivity extends AppCompatActivity {

    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }

    private Button button;
    private OnClickListener btnFunc;
    BluetoothAdapter bluetoothAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*
        // Example of a call to a native method
        TextView tv = findViewById(R.id.sample_text);
        tv.setText(stringFromJNI());
        */
        //TODO create onClick command for sync activity
        //Create button to attach itself
        button = findViewById(R.id.button3);
        //Create button functionality via OnClickListener before attaching it to button
        btnFunc = new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                openSyncActivity();
            }
        };
        button.setOnClickListener(btnFunc);
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
    }
    public void openSyncActivity(){
        //Intent class allows us to use runtime binding and open second activity
        Intent intent = new Intent(this, SyncActivity.class);
        startActivity(intent);
    }


    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.

    public native String stringFromJNI();
     */
}
